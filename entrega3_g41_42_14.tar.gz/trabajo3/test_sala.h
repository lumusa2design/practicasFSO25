#ifndef TEST_SALA_H_
#define TEST_SALA_H_

void ejecuta_tests();

#endif /* TEST_SALA_H_ */
